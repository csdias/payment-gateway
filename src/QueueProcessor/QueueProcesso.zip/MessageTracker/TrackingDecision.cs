namespace QueueProcessor.MessageTracker
{
    public enum TrackingDecision
    {
        ProcessMessage,
        NewerMessageAlreadyReceived
    }
}
