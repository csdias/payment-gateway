using System;

namespace QueueProcessor.Models
{
    public class EventNames
    {
        public const string PaymentOrderEvent = "PaymentOrderEvent";
    }
}
